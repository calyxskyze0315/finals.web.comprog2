from flask import Flask, render_template, session, request, jsonify
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
import json
import os

app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('EV_SECRET_KEY', 'dev-secret-key')
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///ev_store.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

# --- Models ---
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    phone = db.Column(db.String(50), nullable=False)
    password_hash = db.Column(db.String(200), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {'id': self.id, 'name': self.name, 'email': self.email, 'phone': self.phone}

class Order(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    items = db.Column(db.Text, nullable=False)  # JSON string
    total = db.Column(db.Integer, nullable=False)
    buyer_name = db.Column(db.String(120))
    buyer_email = db.Column(db.String(120))
    buyer_phone = db.Column(db.String(50))
    buyer_address = db.Column(db.Text)
    status = db.Column(db.String(50), default='Processing')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    user = db.relationship('User', backref=db.backref('orders', lazy=True))

    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'items': json.loads(self.items),
            'total': self.total,
            'buyer_name': self.buyer_name,
            'buyer_email': self.buyer_email,
            'buyer_phone': self.buyer_phone,
            'buyer_address': self.buyer_address,
            'status': self.status,
            'created_at': self.created_at.isoformat()
        }

# Create DB if not present
with app.app_context():
    db.create_all()

# --- Helper ---
def get_current_user():
    uid = session.get('user_id')
    if not uid:
        return None
    return User.query.get(uid)

# --- Routes ---
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/register', methods=['POST'])
def api_register():
    data = request.get_json() or {}
    name = data.get('name', '').strip()
    email = data.get('email', '').strip().lower()
    phone = data.get('phone', '').strip()
    password = data.get('password', '')

    if not (name and email and phone and password):
        return jsonify({'error': 'Missing fields'}), 400

    if User.query.filter_by(email=email).first():
        return jsonify({'error': 'Email already registered'}), 400

    pw_hash = generate_password_hash(password)
    user = User(name=name, email=email, phone=phone, password_hash=pw_hash)
    db.session.add(user)
    db.session.commit()

    session['user_id'] = user.id
    return jsonify({'user': user.to_dict()}), 201

@app.route('/api/login', methods=['POST'])
def api_login():
    data = request.get_json() or {}
    email = data.get('email', '').strip().lower()
    password = data.get('password', '')

    if not (email and password):
        return jsonify({'error': 'Missing email or password'}), 400

    user = User.query.filter_by(email=email).first()
    if not user or not check_password_hash(user.password_hash, password):
        return jsonify({'error': 'Invalid credentials'}), 401

    session['user_id'] = user.id
    return jsonify({'user': user.to_dict()}), 200

@app.route('/api/logout', methods=['POST'])
def api_logout():
    session.pop('user_id', None)
    return jsonify({'ok': True}), 200

@app.route('/api/whoami', methods=['GET'])
def api_whoami():
    user = get_current_user()
    if not user:
        return jsonify({'user': None}), 200
    return jsonify({'user': user.to_dict()}), 200

@app.route('/api/orders', methods=['GET'])
def api_orders():
    user = get_current_user()
    if not user:
        return jsonify({'error': 'Unauthorized'}), 401
    orders = Order.query.filter_by(user_id=user.id).order_by(Order.created_at.desc()).all()
    return jsonify({'orders': [o.to_dict() for o in orders]}), 200

@app.route('/api/checkout', methods=['POST'])
def api_checkout():
    user = get_current_user()
    if not user:
        return jsonify({'error': 'Unauthorized'}), 401

    data = request.get_json() or {}
    items = data.get('items') or []
    address = data.get('address', '')

    if not items:
        return jsonify({'error': 'No items to checkout'}), 400

    total = sum(int(i.get('price', 0)) * int(i.get('quantity', 1)) for i in items)

    order = Order(
        user_id=user.id,
        items=json.dumps(items),
        total=total,
        buyer_name=user.name,
        buyer_email=user.email,
        buyer_phone=user.phone,
        buyer_address=address,
        status='Processing'
    )

    db.session.add(order)
    db.session.commit()

    return jsonify({'order': order.to_dict()}), 201

if __name__ == '__main__':
    app.run(debug=True, port=3000)