document.addEventListener('DOMContentLoaded', () => {
    const productCards = document.querySelectorAll('.product-card');
    const cartItemsBody = document.getElementById('cart-items-body');
    const cartTotalFooter = document.getElementById('cart-total-footer');
    const proceedCheckoutBtn = document.getElementById('proceed-checkout-btn');
    const orderItemsBody = document.getElementById('order-items-body');
    const orderTotalFooter = document.getElementById('order-total-footer'); // NEW: Added footer for orders
    const confirmPurchaseBtn = document.getElementById('confirm-purchase-btn');
    const feedbackForm = document.getElementById('feedback-form');
    const thankYouMessage = document.getElementById('thank-you-message');
    const notificationBar = document.getElementById('notification-bar');

    let cart = [];
    let orders = [];
    let oneClickProduct = null; // used for immediate single-item purchases (no login) 

    // Load persisted state (localStorage)
    try {
        const savedCart = localStorage.getItem('ev_cart');
        const savedOrders = localStorage.getItem('ev_orders');
        if (savedCart) cart = JSON.parse(savedCart);
        if (savedOrders) orders = JSON.parse(savedOrders);
    } catch (e) {
        console.warn('Failed to parse saved state', e);
    }

    function persistState() {
        localStorage.setItem('ev_cart', JSON.stringify(cart));
        localStorage.setItem('ev_orders', JSON.stringify(orders));
    }

    // --- Account / Registration Integration (server-backed) ---
    let currentUser = null;
    let pendingAction = null; // 'checkout-cart' or 'checkout-oneclick:<json product>'

    async function apiWhoami() {
        try {
            const res = await fetch('/api/whoami', { credentials: 'same-origin' });
            const data = await res.json();
            currentUser = data.user || null;
            updateAccountUI();
            return currentUser;
        } catch (e) {
            console.error('whoami failed', e);
            return null;
        }
    }

    async function apiRegister(payload) {
        const res = await fetch('/api/register', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            credentials: 'same-origin',
            body: JSON.stringify(payload)
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'Registration failed');
        currentUser = data.user;
        updateAccountUI();
        return currentUser;
    }

    function updateAccountUI() {
        const accountNameEl = document.getElementById('account-name');
        const createBtn = document.getElementById('create-account-btn');
        if (currentUser) {
            if (accountNameEl) { accountNameEl.textContent = `Account: ${currentUser.name}`; accountNameEl.style.display = 'inline-block'; }
            if (createBtn) createBtn.style.display = 'none';
        } else {
            if (accountNameEl) accountNameEl.style.display = 'none';
            if (createBtn) createBtn.style.display = 'inline-block';
        }
    }

    // Register modal handling
    const registerModal = document.getElementById('register-modal');
    const registerForm = document.getElementById('register-form');
    const registerCancelBtn = document.getElementById('register-cancel-btn');
    const createAccountBtn = document.getElementById('create-account-btn');

    function openRegisterModal() {
        if (!registerModal) return;
        if (registerForm) registerForm.reset();
        registerModal.classList.add('open');
        registerModal.setAttribute('aria-hidden', 'false');
        const n = document.getElementById('reg-name'); if (n) n.focus();
    }
    function closeRegisterModal() { if (!registerModal) return; registerModal.classList.remove('open'); registerModal.setAttribute('aria-hidden', 'true'); if (registerForm) registerForm.reset(); }

    if (createAccountBtn) createAccountBtn.addEventListener('click', (e) => { e.preventDefault(); openRegisterModal(); });
    if (registerCancelBtn) registerCancelBtn.addEventListener('click', (e) => { e.preventDefault(); closeRegisterModal(); });

    if (registerForm) {
        registerForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const name = document.getElementById('reg-name').value.trim();
            const email = document.getElementById('reg-email').value.trim();
            const phone = document.getElementById('reg-phone').value.trim();
            const password = document.getElementById('reg-password').value;

            if (!name || !email || !phone || !password) { showNotification('Please complete all registration fields.'); return; }
            try {
                await apiRegister({ name, email, phone, password });
                closeRegisterModal();
                showNotification(`Account created. Welcome, ${currentUser.name}!`);
                // If a checkout was pending, continue
                if (pendingAction === 'checkout-cart') { pendingAction = null; showCheckoutModal(); }
                else if (pendingAction && pendingAction.startsWith('checkout-oneclick:')) {
                    try { oneClickProduct = JSON.parse(pendingAction.split(':')[1]); } catch(e){ oneClickProduct = null; }
                    pendingAction = null; showCheckoutModal();
                }
            } catch (err) {
                showNotification(err.message || 'Registration failed.');
            }
        });
    }

    // Check current user on load
    apiWhoami();



    function formatPrice(price) {
        return `₱ ${price.toLocaleString('en-US')}`;
    }

    function showNotification(message) {
        notificationBar.textContent = message;
        notificationBar.classList.add('show');
        setTimeout(() => {
            notificationBar.classList.remove('show');
        }, 3000);
    }

    function updateCartDisplay() {
        cartItemsBody.innerHTML = '';
        let total = 0;

        if (cart.length === 0) {
            cartItemsBody.innerHTML = '<tr><td colspan="4" style="text-align: center; color: #ff00aa;">Cart is empty. Protocol on standby.</td></tr>';
            proceedCheckoutBtn.disabled = true;
        } else {
            cart.forEach((item, index) => {
                const itemTotal = item.price * item.quantity;
                total += itemTotal;

                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${item.name}</td>
                    <td>${formatPrice(item.price)}</td>
                    <td>
                        <input type="number" min="1" value="${item.quantity}" data-index="${index}" class="cart-quantity-input" style="width: 60px; background: #333; color: #fff; border: 1px solid var(--color-primary-neon); padding: 5px; border-radius: 3px;">
                    </td>
                    <td><button class="action-button remove-item-btn" data-index="${index}">REMOVE</button></td>
                `;
                cartItemsBody.appendChild(row);
            });
            proceedCheckoutBtn.disabled = false;
        }

        cartTotalFooter.innerHTML = `<ruby>${formatPrice(total)}<rt>Peso</rt></ruby>`;
    }

    function addToCart(product) {
        const existingItem = cart.find(item => item.id === product.id);

        if (existingItem) {
            existingItem.quantity += 1;
        } else {
            cart.push({ ...product, quantity: 1 });
        }

        updateCartDisplay();
        persistState();
        showNotification(`${product.name} added to cart!`);
    }



    function removeFromCart(index) {
        const removedItemName = cart[index].name;
        cart.splice(index, 1);
        updateCartDisplay();
        persistState();
        showNotification(`${removedItemName} removed from cart!`);
    }

    function updateQuantity(index, newQuantity) {
        const item = cart[index];
        const oldQuantity = item.quantity;
        item.quantity = parseInt(newQuantity);
        
        if (item.quantity < 1 || isNaN(item.quantity)) {
            item.quantity = oldQuantity;
            updateCartDisplay();
            return;
        }

        updateCartDisplay();
        persistState();
    }

    function updateOrderDisplay() {
        orderItemsBody.innerHTML = '';
        let total = 0;

        if (orders.length === 0) {
            orderItemsBody.innerHTML = '<tr><td colspan="4" style="text-align: center; color: var(--color-success);">No confirmed orders awaiting delivery.</td></tr>';
            confirmPurchaseBtn.disabled = true;
            orderTotalFooter.innerHTML = `<ruby>₱ 0<rt>Peso</rt></ruby>`; // I-reset ang total
        } else {
            orders.forEach(item => {
                const itemTotal = item.price * item.quantity;
                total += itemTotal;
                
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${item.name}<br><small style="color:#aaa;">Buyer: ${item.buyer ? item.buyer.name : '—'}</small></td>
                    <td>${formatPrice(item.price)}</td>
                    <td>${item.quantity}</td>
                    <td><span class="status-${item.status}">${item.status.toUpperCase()}</span></td>
                `;
                orderItemsBody.appendChild(row);
            });
            confirmPurchaseBtn.disabled = false;
            orderTotalFooter.innerHTML = `<ruby>${formatPrice(total)}<rt>Peso</rt></ruby>`; // Ipakita ang total
        }
    }

    function proceedToCheckout() {
        if (cart.length === 0 && !oneClickProduct) return;
        if (!currentUser) { pendingAction = 'checkout-cart'; openRegisterModal(); return; }
        showCheckoutModal();
    }

    // Checkout modal handling
    const checkoutModal = document.getElementById('checkout-modal');
    const checkoutForm = document.getElementById('checkout-form');
    const checkoutSummary = document.getElementById('checkout-summary');
    const checkoutCancelBtn = document.getElementById('checkout-cancel-btn');
    const checkoutCancelBtn2 = document.getElementById('checkout-cancel-btn-2');

    function showCheckoutModal() {
        if (!checkoutModal) return;
        const subtotal = oneClickProduct ? oneClickProduct.price : cart.reduce((s, it) => s + it.price * it.quantity, 0);
        const itemsCount = oneClickProduct ? 1 : cart.length;
        checkoutSummary.textContent = `You have ${itemsCount} item(s). Subtotal: ${formatPrice(subtotal)}`;
        if (checkoutForm) checkoutForm.reset();

        // If a user is logged in, pre-fill the buyer fields from account and disable editing (except address)
        const nameInput = document.getElementById('buyer-name');
        const emailInput = document.getElementById('buyer-email');
        const phoneInput = document.getElementById('buyer-phone');
        const addressInput = document.getElementById('buyer-address');

        if (currentUser) {
            if (nameInput) { nameInput.value = currentUser.name; nameInput.disabled = true; }
            if (emailInput) { emailInput.value = currentUser.email; emailInput.disabled = true; }
            if (phoneInput) { phoneInput.value = currentUser.phone; phoneInput.disabled = true; }
            if (addressInput) addressInput.focus();
        } else {
            if (nameInput) { nameInput.disabled = false; }
            if (emailInput) { emailInput.disabled = false; }
            if (phoneInput) { phoneInput.disabled = false; }
            if (nameInput) nameInput.focus();
        }

        checkoutModal.classList.add('open');
        checkoutModal.setAttribute('aria-hidden', 'false');
    }

    function closeCheckoutModal() {
        if (!checkoutModal) return;
        // Re-enable inputs in case they were disabled for logged-in users
        const nameInput = document.getElementById('buyer-name');
        const emailInput = document.getElementById('buyer-email');
        const phoneInput = document.getElementById('buyer-phone');
        if (nameInput) nameInput.disabled = false;
        if (emailInput) emailInput.disabled = false;
        if (phoneInput) phoneInput.disabled = false;

        checkoutModal.classList.remove('open');
        checkoutModal.setAttribute('aria-hidden', 'true');
        if (checkoutForm) checkoutForm.reset();
    }

    if (checkoutCancelBtn) checkoutCancelBtn.addEventListener('click', (e) => { e.preventDefault(); closeCheckoutModal(); });
    if (checkoutCancelBtn2) checkoutCancelBtn2.addEventListener('click', (e) => { e.preventDefault(); closeCheckoutModal(); });

    if (checkoutModal) {
        checkoutModal.addEventListener('click', (e) => {
            if (e.target === checkoutModal) closeCheckoutModal();
        });
    }

    if (checkoutForm) {
        checkoutForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const name = document.getElementById('buyer-name').value.trim();
            const email = document.getElementById('buyer-email').value.trim();
            const phone = document.getElementById('buyer-phone').value.trim();
            const address = document.getElementById('buyer-address').value.trim();

            if (!address) {
                showNotification('Please provide your address for delivery.');
                return;
            }

            // If not logged in, force registration before completing checkout
            if (!currentUser) {
                if (oneClickProduct) pendingAction = 'checkout-oneclick:' + JSON.stringify(oneClickProduct);
                else pendingAction = 'checkout-cart';
                closeCheckoutModal();
                openRegisterModal();
                showNotification('Please create an account first.');
                return;
            }

            // Build items payload
            let items = [];
            if (oneClickProduct) {
                items = [{ id: oneClickProduct.id, name: oneClickProduct.name, price: oneClickProduct.price, quantity: 1 }];
            } else {
                items = cart.map(item => ({ id: item.id, name: item.name, price: item.price, quantity: item.quantity }));
            }

            try {
                const res = await fetch('/api/checkout', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    credentials: 'same-origin',
                    body: JSON.stringify({ items, address })
                });
                const data = await res.json();
                if (!res.ok) throw new Error(data.error || 'Checkout failed');

                // Convert returned server order into the local orders display format
                const srv = data.order;
                const displayOrder = {
                    id: srv.id,
                    name: items.map(i => i.name).join(', '),
                    price: srv.total,
                    quantity: items.reduce((s, i) => s + (i.quantity || 1), 0),
                    status: srv.status,
                    orderId: srv.id,
                    buyer: { name: srv.buyer_name, email: srv.buyer_email }
                };

                orders = [displayOrder, ...orders];

                // Clear cart / oneClick flags
                oneClickProduct = null;
                cart = [];

                persistState();
                updateCartDisplay();
                updateOrderDisplay();
                closeCheckoutModal();
                showNotification('Checkout complete. Order saved to your account.');
            } catch (err) {
                showNotification(err.message || 'Checkout failed.');
            }
        });
    }

    function confirmDelivery() {
        if (orders.length === 0) return;

        const confirmedCount = orders.length;
        orders = []; 

        updateOrderDisplay();
        showNotification(`Delivery Confirmed for ${confirmedCount} order(s)! Thank you for your purchase.`);
    }









    // Account controls removed (login/register were disabled per latest requirements)
    // No accountBtn or logoutBtn present in the current UI


    productCards.forEach(card => {
        const productId = card.dataset.productId;
        const productName = card.dataset.name;
        const productPrice = parseInt(card.dataset.price);

        const product = { id: productId, name: productName, price: productPrice };

        const addToCartBtn = card.querySelector('.add-to-cart-btn');
        const purchaseBtn = card.querySelector('.purchase-btn');

        addToCartBtn.addEventListener('click', (e) => {
            e.preventDefault();
            addToCart(product);
        });

        // "Purchase Now": require account first, then open checkout for single item
        purchaseBtn.addEventListener('click', (e) => {
            e.preventDefault();
            if (!currentUser) {
                pendingAction = 'checkout-oneclick:' + JSON.stringify(product);
                openRegisterModal();
                return;
            }
            oneClickProduct = product;
            showCheckoutModal();
            document.getElementById('orders').scrollIntoView({ behavior: 'smooth' });
        });
    });

    // Initialize account UI on load
    updateAccountUI();

    cartItemsBody.addEventListener('click', (e) => {
        if (e.target.classList.contains('remove-item-btn')) {
            const index = parseInt(e.target.dataset.index);
            removeFromCart(index);
        }
    });

    cartItemsBody.addEventListener('change', (e) => {
        if (e.target.classList.contains('cart-quantity-input')) {
            const index = parseInt(e.target.dataset.index);
            const newQuantity = e.target.value;
            updateQuantity(index, newQuantity);
        }
    });

    proceedCheckoutBtn.addEventListener('click', proceedToCheckout);
    confirmPurchaseBtn.addEventListener('click', confirmDelivery);

    feedbackForm.addEventListener('submit', (e) => {
        e.preventDefault();
        
        const feedbackText = document.getElementById('feedback-text').value;

        if (feedbackText.trim() === "") {
            showNotification("Please enter your feedback before submitting.");
            return;
        }

        const formData = new FormData(feedbackForm);
        console.log("--- FEEDBACK FORM SUBMISSION DATA (POST) ---");
        for (const [key, value] of formData.entries()) {
            console.log(`${key}: ${value instanceof File ? value.name : value}`);
        }
        console.log("------------------------------------------");

        feedbackForm.style.display = 'none';
        thankYouMessage.style.display = 'block';
        setTimeout(() => {
            thankYouMessage.style.opacity = '1';
        }, 10);
        
        showNotification("Feedback submitted successfully! Thank you.");
    });
    
    const subscribeForm = document.getElementById('subscribeForm');
    const btnImage = document.getElementById('btn_image');
    const adrInput = document.getElementById('adr');
    const validationMessage = document.getElementById('validation-message');
    
    if (btnImage) {
        btnImage.addEventListener('click', function (e) {
            e.preventDefault();
            validationMessage.textContent = '';

            const pattern = /^([a-zA-Z0-9_.-])+@([a-zA-Z0-9_.-])+\.([a-zA-Z])+([a-zA-Z])+$/;
            let adr = adrInput.value;

            if (!pattern.test(adr)) {
                validationMessage.textContent = 'ERROR: Invalid Email Address Format.';
                validationMessage.style.color = 'var(--color-error)';
                showNotification('Invalid Email Address! Please review.');
            } else {
                validationMessage.textContent = `SUCCESS! Email ${adr} is Valid and Subscribed! (Form Submitted)`;
                validationMessage.style.color = 'var(--color-success)';
                showNotification('Email is valid! Subscription Protocol Engaged.');
                
                adrInput.value = '';
            }
        });
    }

    // Initialize local displays
    updateCartDisplay();
    updateOrderDisplay();
});